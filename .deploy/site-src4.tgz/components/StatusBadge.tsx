import type { Status } from "@/content/data";
const tone: Record<Status, string> = {
  Concept: "border-soft/40 text-soft",
  Research: "border-blue/50 text-blue",
  Prototype: "border-blue/50 text-blue",
  "In Development": "border-accent/60 text-accent",
  Launched: "border-accent bg-accent/15 text-accent",
  Archived: "border-soft/40 text-soft",
};
export function StatusBadge({ status }: { status?: Status }) {
  if (!status) return <span className="chip border-soft/40">Employer work</span>;
  return <span className={`chip ${tone[status]}`}>{status}</span>;
}
