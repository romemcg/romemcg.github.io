import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { caseStudies } from "@/content/data";
import { Reveal } from "@/components/Reveal";
import { FlowDiagram } from "@/components/FlowDiagram";

export function generateStaticParams() { return caseStudies.map((c) => ({ slug: c.slug })); }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params; const c = caseStudies.find((x) => x.slug === slug);
  return c ? { title: c.title, description: c.blurb } : {};
}

export default async function CaseStudy({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const c = caseStudies.find((x) => x.slug === slug);
  if (!c) notFound();
  const Sec = ({ t, children }: { t: string; children: React.ReactNode }) => <Reveal><section className="border-t border-line/10 py-8"><h2 className="display text-2xl">{t}</h2><div className="prose-s mt-3">{children}</div></section></Reveal>;
  const ul = (a: string[]) => <ul>{a.map((x) => <li key={x}>{x}</li>)}</ul>;
  return (
    <article className="wrap max-w-3xl pb-10 pt-16 md:pt-24">
      <Link href="/case-studies/" className="text-sm text-soft hover:text-accent">← All case studies</Link>
      <p className="eyebrow mt-6">{c.category}</p>
      <h1 className="display mt-2 text-[clamp(2.2rem,6vw,3.8rem)]">{c.title}</h1>
      <p className="mt-3 text-soft">{c.context}</p>
      <div className="mt-8">
        <Reveal><div className="mb-2 rounded-[1.5rem] bg-tint p-5 md:p-8"><FlowDiagram steps={c.flow} /></div></Reveal>
        <Sec t="The problem"><p>{c.problem}</p></Sec>
        <Sec t="What I did">{ul(c.approach)}</Sec>
        <Sec t="Decisions and trade offs">{ul(c.decisions)}</Sec>
        <Sec t="Outcome">{ul(c.outcome)}</Sec>
        <Sec t="What I took from it"><p>{c.learned}</p></Sec>
      </div>
    </article>
  );
}
