import Link from "next/link";

export function Wordmark({ onClick, large }: { onClick?: () => void; large?: boolean }) {
  return (
    <Link href="/" onClick={onClick} aria-label="Mark Gomez, home" className="group inline-flex items-center gap-2.5">
      <span className="grid place-items-center rounded-xl text-white shadow-md transition group-hover:rotate-[-6deg]" style={{ width: large ? 44 : 36, height: large ? 44 : 36, background: "linear-gradient(135deg, rgb(var(--blue)), rgb(var(--accent)))", fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: large ? 18 : 15, letterSpacing: "-0.06em" }}>MG</span>
      <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, letterSpacing: "-0.04em", fontSize: large ? "1.6rem" : "1.2rem", lineHeight: 1 }}>
        mark<span className="grad">gomez</span>
      </span>
    </Link>
  );
}
