import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { projects } from "@/content/data";
import { StatusBadge } from "@/components/StatusBadge";
import { Reveal } from "@/components/Reveal";
import { ProjectCover } from "@/components/ProjectCover";
import { TechIcon } from "@/components/Icons";
import { FlowDiagram } from "@/components/FlowDiagram";

export function generateStaticParams() { return projects.map((p) => ({ slug: p.slug })); }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params; const p = projects.find((x) => x.slug === slug);
  return p ? { title: p.name, description: p.blurb } : {};
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return <Reveal><section className="border-t border-line/10 py-8"><h2 className="display text-2xl">{title}</h2><div className="prose-s mt-3">{children}</div></section></Reveal>;
}

export default async function ProjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const p = projects.find((x) => x.slug === slug);
  if (!p) notFound();
  const list = (a?: string[]) => a && <ul>{a.map((x) => <li key={x}>{x}</li>)}</ul>;
  return (
    <article className="wrap max-w-3xl pb-10 pt-16 md:pt-24">
      <Link href="/projects/" className="text-sm text-soft hover:text-accent">← All projects</Link>
      <div className="mt-6 flex items-center gap-3"><StatusBadge status={p.status} /><span className="text-sm text-soft">{p.period} · {p.type}</span></div>
      <h1 className="display mt-3 text-[clamp(2.4rem,7vw,4.2rem)]">{p.name}</h1>
      {!p.gallery && <div className="mt-6"><ProjectCover index={projects.indexOf(p)} tech={p.tech} title={p.name} slug={p.slug} /></div>}
      <p className="mt-4 text-xl text-ink/80">{p.blurb}</p>
      {p.links?.some((l) => l.label.startsWith("Live")) && (
        <div className="mt-5 flex flex-wrap gap-3">
          {p.links.filter((l) => l.label.startsWith("Live")).map((l) => (
            <a key={l.href} href={l.href} target="_blank" rel="noopener noreferrer" className="btn btn-accent !px-6 !py-3">{l.label.startsWith("Live demo") ? "Open the live demo" : "Open the live platform"} <span aria-hidden>↗</span></a>
          ))}
        </div>
      )}
      <div className="mt-5 flex flex-wrap gap-1.5">{p.tech.map((t) => <span key={t} className="chip gap-1.5"><TechIcon name={t} className="h-3 w-3" />{t}</span>)}</div>
      {p.shot && (
        <figure className="mt-8">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={p.shot.src} alt={p.shot.alt} width={412} height={800} loading="lazy" className="mx-auto h-auto w-full max-w-[260px] rounded-[2rem] shadow-lg" />
          <figcaption className="mt-3 text-center text-sm text-soft">{p.shot.caption}</figcaption>
        </figure>
      )}
      {p.gallery && (
        <div className="mt-8 grid gap-6 sm:grid-cols-2">
          {p.gallery.map((g, i) => (
            <Reveal key={g.src}>
              <figure className={i === 0 ? "sm:col-span-2" : ""}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={g.src} alt={g.alt} width={1600} height={900} loading={i === 0 ? "eager" : "lazy"} className="h-auto w-full rounded-2xl border border-line/10 shadow-lg" />
                <figcaption className="mt-2 text-sm text-soft">{g.caption}</figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      )}
      <div className="mt-8">
        {p.flow && <Block title="The flow"><div className="not-prose"><FlowDiagram steps={p.flow} /></div></Block>}
        {p.problem && <Block title="The problem"><p>{p.problem}</p></Block>}
        {p.users && <Block title="Who it is for"><p>{p.users}</p></Block>}
        {p.role && <Block title="My role"><p>{p.role}</p></Block>}
        {p.approach && <Block title="Approach">{list(p.approach)}</Block>}
        {p.decisions && <Block title="Product decisions">{list(p.decisions)}</Block>}
        {p.results && <Block title="Results">{list(p.results)}</Block>}
        {p.roadmap && <Block title="What is next">{list(p.roadmap)}</Block>}
        {p.links && <Block title="Links"><ul>{p.links.map((l) => <li key={l.href}><a className="underline decoration-accent" href={l.href}>{l.label}</a></li>)}</ul></Block>}
      </div>
    </article>
  );
}
