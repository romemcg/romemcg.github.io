"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { certs, education, outcomes, recruiterSummary, roles, site } from "@/content/data";
import { CountUp } from "./CountUp";
import { Logo } from "./Logo";

export function CareerView() {
  const [view, setView] = useState<"recruiter" | "full">("recruiter");
  const [openRole, setOpenRole] = useState<string | null>(null);
  return (
    <div>
      <div role="tablist" aria-label="Career view" className="no-print inline-flex rounded-full border border-line/20 p-1">
        {([["recruiter", "Recruiter view"], ["full", "Full journey"]] as const).map(([k, l]) => (
          <button key={k} role="tab" aria-selected={view === k} onClick={() => setView(k)} className={`rounded-full px-5 py-2 text-sm font-semibold transition ${view === k ? "bg-ink text-bg" : "hover:text-accent"}`}>{l}</button>
        ))}
      </div>

      {view === "recruiter" && (
        <div className="mt-8 grid gap-8 lg:grid-cols-[1.6fr_1fr]">
          <div>
            <p className="max-w-2xl text-lg leading-relaxed">{recruiterSummary}</p>
            <h2 className="display mt-10 text-2xl">Experience</h2>
            <div className="mt-3 divide-y divide-line/10 rounded-2xl border border-line/10">
              {roles.map((r) => (
                <div key={r.id} className="grid gap-1 p-4 md:grid-cols-[1fr_auto]">
                  <div><p className="font-semibold">{r.title}</p><p className="text-soft">{r.company}, {r.place}</p></div>
                  <p className="text-sm text-soft md:text-right">{r.dates}</p>
                </div>
              ))}
            </div>
            <h2 className="display mt-10 text-2xl">Selected outcomes</h2>
            <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">
              {outcomes.map((o) => (
                <div key={o.label} className="card p-4"><p className="display text-4xl text-accent"><CountUp value={o.value} /></p><p className="mt-1 text-sm">{o.label}</p><p className="mt-1 text-xs text-soft">{o.where}</p></div>
              ))}
            </div>
            <p className="mt-3 text-sm text-soft">Also: an AED 30M+ digital platforms portfolio at Aldar and a 95%+ UAT success rate at Disrupt-X. Figures are approximate.</p>
          </div>
          <aside className="space-y-6">
            <div className="card p-5"><h2 className="display text-xl">Credentials</h2><ul className="mt-3 space-y-2 text-sm">{certs.map((c) => <li key={c}>{c}</li>)}</ul></div>
            <div className="card p-5"><h2 className="display text-xl">Education</h2><ul className="mt-3 space-y-3 text-sm">{education.map((e) => <li key={e.school} className="flex items-center gap-3"><Logo id={e.school.startsWith("Univ") ? "ub" : "pcu"} name={e.school} size={40} /><span><b>{e.what}</b><br />{e.school}, {e.dates}</span></li>)}</ul></div>
            <div className="card p-5"><h2 className="display text-xl">Core strengths</h2><p className="mt-3 text-sm leading-relaxed">Product strategy and roadmaps · PRDs and system blueprints · APIs and data flows · Multi vendor delivery · UAT and release readiness · RAID and change control · Stakeholder management · IoT, AIoT and digital twins · Power BI, Jira, MS Project · AI assisted product workflows</p></div>
            <div className="card p-5"><h2 className="display text-xl">Reach me</h2><p className="mt-3 text-sm"><a className="underline decoration-accent" href={`mailto:${site.email}`}>{site.email}</a><br /><a className="underline decoration-accent" href={site.linkedin}>LinkedIn</a><br />{site.base}</p><p className="mt-2 text-sm"><a className="underline decoration-accent" href="/recommendations/">Read recommendations</a></p></div>
          </aside>
        </div>
      )}

      {view === "full" && (
        <div className="mt-8 space-y-4">
          {roles.map((r) => {
            const on = openRole === r.id;
            return (
              <div key={r.id} className="card overflow-hidden">
                <button onClick={() => setOpenRole(on ? null : r.id)} aria-expanded={on} className="flex w-full items-start justify-between gap-4 p-6 text-left">
                  <div className="flex items-start gap-4"><Logo id={r.id} name={r.company} size={48} /><div><p className="text-sm text-soft">{r.dates} · {r.place}</p><h3 className="display mt-1 text-2xl">{r.company}</h3><p className="mt-1">{r.title}</p>{r.earlier && <p className="text-sm text-soft">Earlier: {r.earlier}</p>}</div></div>
                  <span aria-hidden className={`text-2xl transition ${on ? "rotate-45" : ""}`}>+</span>
                </button>
                <AnimatePresence initial={false}>
                  {on && (
                    <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden">
                      <div className="grid gap-6 border-t border-line/10 p-6 md:grid-cols-[1.6fr_1fr]">
                        <div><p className="text-ink/80">{r.summary}</p><ul className="prose-s mt-4">{r.bullets.map((b) => <li key={b}>{b}</li>)}</ul></div>
                        <div><p className="text-sm font-semibold">Tools and methods</p><div className="mt-2 flex flex-wrap gap-1.5">{r.tools.map((t) => <span key={t} className="chip">{t}</span>)}</div><p className="mt-5 text-sm font-semibold">Transferable skills</p><ul className="mt-2 space-y-1 text-sm">{r.transferable.map((t) => <li key={t}>✦ {t}</li>)}</ul></div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
