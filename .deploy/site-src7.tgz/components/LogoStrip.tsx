import { Logo } from "./Logo";
import { TechIcon } from "./Icons";
import { Reveal } from "./Reveal";

const places = [["samsung", "Samsung Electro-Mechanics"], ["disruptx", "Disrupt-X"], ["aldar", "Aldar Properties"], ["terminus", "Terminus Group"]];
const tech = ["Next.js", "React", "TypeScript", "Tailwind CSS", "Rust", "SQLite", "Expo", "Claude"];

export function LogoStrip() {
  return (
    <Reveal className="wrap pb-10">
      <p className="text-center text-xs font-semibold uppercase tracking-[0.18em] text-soft">Where I have worked</p>
      <div className="mt-5 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
        {places.map(([id, n]) => (
          <div key={id} className="flex items-center gap-3"><Logo id={id} name={n} size={40} /><span className="font-semibold">{n.replace(" Electro-Mechanics", "").replace(" Properties", "").replace(" Group", "")}</span></div>
        ))}
      </div>
      <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-soft">
        {tech.map((t) => <span key={t} title={t} className="flex items-center gap-2 text-sm"><TechIcon name={t} className="h-5 w-5" />{t}</span>)}
      </div>
    </Reveal>
  );
}
