"use client";
import { useEffect, useRef } from "react";

// Interactive dot grid: dots bulge away from the cursor and link up like a circuit, with a slow ambient scan.
export function TechBackground() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!;
    const ctx = c.getContext("2d")!;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const GAP = 40, R = 260;
    const glyphs = ["01", "10", "{ }", "</>", "0x", "IoT", "AI", "#", "::", "&&"];
    let w = 0, h = 0, dpr = 1, raf = 0, rgb = "37 99 235";
    type Dot = { ox: number; oy: number; x: number; y: number };
    let dots: Dot[] = [], cols = 0;
    const m = { x: -9999, y: -9999, tx: -9999, ty: -9999 };
    const readColor = () => { rgb = getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() || rgb; };
    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth; h = window.innerHeight;
      c.width = w * dpr; c.height = h * dpr; c.style.width = w + "px"; c.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      dots = []; cols = Math.ceil(w / GAP) + 1;
      for (let y = 0; y <= h + GAP; y += GAP) for (let x = 0; x <= w + GAP; x += GAP) dots.push({ ox: x, oy: y, x, y });
    };
    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h);
      m.x += (m.tx - m.x) * 0.14; m.y += (m.ty - m.y) * 0.14;
      const inf: number[] = new Array(dots.length);
      for (let i = 0; i < dots.length; i++) {
        const d = dots[i];
        const dx = d.ox - m.x, dy = d.oy - m.y, dist = Math.hypot(dx, dy) || 1;
        const k = Math.max(0, 1 - dist / R); inf[i] = k;
        const push = k * k * 34;
        d.x += (d.ox + (dx / dist) * push - d.x) * 0.18;
        d.y += (d.oy + (dy / dist) * push - d.y) * 0.18;
        const scan = 0.5 + 0.5 * Math.sin(t * 0.0009 - (d.ox + d.oy) * 0.006);
        const a = 0.05 + scan * 0.04 + k * 0.75;
        ctx.fillStyle = `rgb(${rgb} / ${a})`;
        ctx.beginPath(); ctx.arc(d.x, d.y, 1.1 + k * 2.6, 0, 6.2832); ctx.fill();
      }
      // masked reveal: code glyphs only visible through the cursor spotlight
      ctx.font = "11px ui-monospace, monospace"; ctx.textAlign = "center";
      for (let i = 0; i < dots.length; i += 3) {
        if (inf[i] < 0.08 || (i * 7919) % 5 > 1) continue;
        ctx.fillStyle = `rgb(${rgb} / ${inf[i] * 0.9})`;
        ctx.fillText(glyphs[(i * 31) % glyphs.length], dots[i].x + GAP / 2, dots[i].y + GAP / 2 + 4);
      }
      ctx.lineWidth = 1;
      for (let i = 0; i < dots.length; i++) {
        if (inf[i] < 0.12) continue;
        const r = dots[i + 1], b = dots[i + cols];
        for (const n of [r, b]) {
          const j = n === r ? i + 1 : i + cols;
          if (!n || (n === r && (i + 1) % cols === 0) || inf[j] < 0.12) continue;
          ctx.strokeStyle = `rgb(${rgb} / ${Math.min(inf[i], inf[j]) * 0.55})`;
          ctx.beginPath(); ctx.moveTo(dots[i].x, dots[i].y); ctx.lineTo(n.x, n.y); ctx.stroke();
        }
      }
      if (m.x > -999) {
        const g = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, R);
        g.addColorStop(0, `rgb(${rgb} / 0.14)`); g.addColorStop(1, `rgb(${rgb} / 0)`);
        ctx.fillStyle = g; ctx.fillRect(m.x - R, m.y - R, R * 2, R * 2);
      }
    };
    const loop = (t: number) => { if (!document.hidden) draw(t); raf = requestAnimationFrame(loop); };
    const move = (e: PointerEvent) => { m.tx = e.clientX; m.ty = e.clientY; if (m.x < -999) { m.x = e.clientX; m.y = e.clientY; } };
    const leave = () => { m.tx = -9999; m.ty = -9999; m.x = -9999; m.y = -9999; };
    readColor(); resize();
    const mo = new MutationObserver(readColor); mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    window.addEventListener("resize", resize);
    if (reduce) { draw(0); } else {
      window.addEventListener("pointermove", move); document.addEventListener("pointerleave", leave);
      raf = requestAnimationFrame(loop);
    }
    return () => { cancelAnimationFrame(raf); mo.disconnect(); window.removeEventListener("resize", resize); window.removeEventListener("pointermove", move); document.removeEventListener("pointerleave", leave); };
  }, []);
  return <canvas ref={ref} aria-hidden className="pointer-events-none fixed inset-0 -z-10" />;
}
