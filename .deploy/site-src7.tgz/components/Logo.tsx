import Image from "next/image";

// Real logos in public/logos. Light-on-transparent marks sit on a navy tile, the rest on white.
const logos: Record<string, { src: string; w: number; h: number; dark?: boolean }> = {
  samsung: { src: "/logos/samsung.png", w: 600, h: 200 },
  aldar: { src: "/logos/aldar.png", w: 600, h: 622 },
  disruptx: { src: "/logos/disruptx.png", w: 155, h: 40 },
  terminus: { src: "/logos/terminus.png", w: 174, h: 22, dark: true },
  ub: { src: "/logos/ub.png", w: 437, h: 437 },
  pcu: { src: "/logos/pcu.png", w: 313, h: 312 },
};

export function Logo({ id, name, size = 56 }: { id: string; name: string; src?: string; size?: number }) {
  const l = logos[id];
  if (!l) return null;
  const wide = l.w / l.h > 2;
  return (
    <span className="inline-grid shrink-0 place-items-center overflow-hidden rounded-2xl border border-line/10 shadow-sm" role="img" aria-label={`${name} logo`}
      style={{ background: l.dark ? "#0C2340" : "#fff", height: size, width: wide ? size * 2.2 : size, padding: size * 0.14 }}>
      <Image src={l.src} alt="" width={l.w} height={l.h} style={{ maxHeight: "100%", maxWidth: "100%", width: "auto", height: "auto", objectFit: "contain" }} />
    </span>
  );
}
