import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";
import { ContactForm } from "@/components/ContactForm";
import { site } from "@/content/data";
import { GithubIcon, LinkedinIcon, MailIcon } from "@/components/Icons";

export const metadata: Metadata = { title: "Contact", description: "Get in touch about roles, collaboration or projects." };

export default function Contact() {
  return (
    <>
      <PageHeader eyebrow="Contact" title="Let's connect." intro="Product roles, collaboration or a project idea. The fastest way to reach me is email." />
      <section className="wrap py-8">
        <div className="grid gap-4 md:grid-cols-3">
          {[[`mailto:${site.email}`, "Email", site.email, <MailIcon key="m" className="h-6 w-6" />], [site.linkedin, "LinkedIn", "linkedin.com/in/romemcg", <LinkedinIcon key="l" className="h-6 w-6" />], [site.github, "GitHub", "github.com/romemcg", <GithubIcon key="g" className="h-6 w-6" />]].map(([h, t, s, i]) => (
            <a key={t as string} href={h as string} className="card group flex items-center gap-4 p-5 transition hover:-translate-y-1 hover:border-accent/50">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-accent/10 text-accent">{i}</span>
              <span className="min-w-0"><span className="block font-semibold">{t}</span><span className="block truncate text-sm text-soft">{s}</span></span>
            </a>
          ))}
        </div>
        <p className="mt-6 text-soft">Based in the {site.base}.</p>
        {site.formEndpoint && <div className="mt-8 max-w-xl"><ContactForm /></div>}
      </section>
    </>
  );
}
