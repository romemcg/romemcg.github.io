import type { Metadata, Viewport } from "next";
import "./globals.css";
import { TechBackground } from "@/components/TechBackground";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { Providers } from "@/components/Providers";
import { site } from "@/content/data";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name} | Product Manager and Builder`, template: `%s | ${site.name}` },
  description: "Mark Gomez is an electronics engineer turned product manager based in the UAE. Platform products, IoT and AIoT, smart cities, and things he builds.",
  openGraph: { title: `${site.title}`, description: site.tagline, url: site.url, siteName: site.title, type: "website", images: [{ url: "/img/mark.webp", width: 600, height: 750, alt: "Mark Gomez" }] },
  twitter: { card: "summary_large_image", title: site.title, description: site.tagline, images: ["/img/mark.webp"] },
  alternates: { canonical: "/" },
};
export const viewport: Viewport = { themeColor: [{ media: "(prefers-color-scheme: light)", color: "#FFFFFF" }, { media: "(prefers-color-scheme: dark)", color: "#070E1C" }] };

const themeScript = `try{var t=localStorage.getItem('theme');if(!t){t=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'}document.documentElement.setAttribute('data-theme',t)}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const ld = {
    "@context": "https://schema.org", "@type": "Person", name: site.fullName, alternateName: site.name, url: site.url,
    email: site.email, sameAs: [site.linkedin, site.github], address: { "@type": "PostalAddress", addressCountry: "AE" },
    alumniOf: [{ "@type": "CollegeOrUniversity", name: "University of Batangas" }, { "@type": "CollegeOrUniversity", name: "Philippine Christian University" }],
    jobTitle: "Product Manager",
  };
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600&display=swap" rel="stylesheet" />
        <noscript><style>{`[style*="opacity: 0"]{opacity:1!important;transform:none!important}`}</style></noscript>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      </head>
      <body>
        <a href="#main" className="skip">Skip to content</a>
        <Providers>
          <Nav />
          <TechBackground />
          <main id="main">{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
