import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { Reveal } from "@/components/Reveal";
import { ProjectCover } from "@/components/ProjectCover";
import { caseStudies } from "@/content/data";

export const metadata: Metadata = { title: "Case Studies", description: "How I think: problems, decisions and trade-offs, with demonstrated outcomes kept separate from hypotheses." };

export default function CaseStudies() {
  return (
    <>
      <PageHeader eyebrow="Case studies" title="How I think." intro="Problems, decisions and trade offs, from my roles and my own projects." />
      <section className="wrap grid gap-6 py-8">
        {caseStudies.map((c, i) => (
          <Reveal key={c.slug} delay={i * 0.06}>
            <article className="card group relative p-7 transition hover:-translate-y-1 hover:border-accent/60 md:p-10">
              <div className="mb-6"><ProjectCover index={i + 1} tech={[]} title={c.title} slug={c.slug} /></div>
              <p className="eyebrow">{c.category}</p>
              <h2 className="display mt-2 text-3xl md:text-4xl"><Link href={`/case-studies/${c.slug}/`} className="after:absolute after:inset-0">{c.title}</Link></h2>
              <p className="mt-3 max-w-2xl text-ink/80">{c.blurb}</p>
              <div className="mt-5 flex flex-wrap items-center gap-2 text-xs text-soft">{c.flow.map((f, k) => <span key={f} className="flex items-center gap-2"><span className="rounded-full bg-tint px-3 py-1 font-medium text-ink">{f}</span>{k < c.flow.length - 1 && <span aria-hidden className="text-accent">→</span>}</span>)}</div>
            </article>
          </Reveal>
        ))}
      </section>
    </>
  );
}
