// All public content lives here. Edit this file (or the typed objects below) to change the site.
// All public content lives here.

export const site = {
  url: "https://romemcg.github.io",
  name: "Mark Gomez",
  fullName: "Mark Jerome Castillo Gomez",
  title: "Mark Gomez",
  tagline: "Product manager and builder based in the UAE.",
  email: "mjerome.gomez@gmail.com",
  linkedin: "https://www.linkedin.com/in/romemcg",
  github: "https://github.com/romemcg",
  base: "United Arab Emirates",
  home: "Batangas, Philippines",
  updated: "19 October 2026",
  // Set to a Formspree (or similar) endpoint to turn the contact form on. Leave empty for email only.
  formEndpoint: "",
};

export const identity = [
  "Engineer by training.",
  "Builder by curiosity.",
  "Product thinker.",
  "Always evolving.",
];

export type Status = "Concept" | "Research" | "Prototype" | "In Development" | "Launched" | "Archived";

export type Outcome = { value: string; label: string; where: string };
export const outcomes: Outcome[] = [
  { value: "~40%", label: "faster infrastructure failure response", where: "Aldar" },
  { value: "~30%", label: "gain in monitoring efficiency", where: "Aldar" },
  { value: "~25%", label: "lower energy costs", where: "Aldar" },
  { value: "~15%", label: "platform adoption growth", where: "Disrupt-X" },
];

export type Role = {
  id: string;
  logo?: string;
  company: string;
  place: string;
  title: string;
  earlier?: string;
  dates: string;
  start: number; // year, for ordering
  summary: string;
  bullets: string[];
  tools: string[];
  transferable: string[];
};

export const roles: Role[] = [
  {
    id: "terminus",
    company: "Terminus Group",
    place: "Dubai, UAE",
    title: "Product Manager, Enterprise AI and IoT Platforms",
    dates: "Oct 2025 to Aug 2026",
    start: 2025,
    summary: "AIoT and Digital Twin platforms for large real estate and infrastructure portfolios across the GCC, with presales and solution definition alongside product ownership.",
    bullets: [
      "Owned product definition and the documentation suite: PRDs, system blueprints and integration flow specifications across device, middleware and application layers.",
      "Structured and prioritised the roadmap from field deployment feedback, system constraints and long term scalability.",
      "Set technical governance standards covering cybersecurity, data integrity and lifecycle maintainability.",
      "Supported presales and solution development for enterprise and government opportunities, including Dubai Municipality wastewater management, Miral Smart Destination and Al Wasl Smart Home.",
    ],
    tools: ["PRDs", "System blueprints", "Integration specs", "Digital twin", "AIoT"],
    transferable: ["Product strategy", "Presales and solution framing", "Technical governance"],
  },
  {
    id: "aldar",
    company: "Aldar Properties PJSC",
    place: "Abu Dhabi, UAE",
    title: "Product Owner and Smart City Lead, Digital Platforms",
    dates: "Oct 2024 to Oct 2025",
    start: 2024,
    summary: "Took smart community technology from master plan vision to daily operations across Saadiyat, Mamsha and The Grove, with multiple vendors and thousands of homes.",
    bullets: [
      "Owned digital use cases, technical standards and integration frameworks across IoT, mobility, parking and building intelligence, for a digital platforms portfolio valued at AED 30M+.",
      "Coordinated Siemens, ID Cube, Parkonic and internal ICT, sustainability and operations teams through design, integration, testing and acceptance.",
      "Designed the Smart City Solution Blueprint, a reusable scoring framework for use cases and vendors, applied across three developments.",
      "Set MVP site selection criteria and post deployment adoption tracking.",
      "Platform and workflow improvements contributed to about 30% better environmental monitoring efficiency, about 40% faster infrastructure failure response and about 25% lower energy costs.",
    ],
    tools: ["Power BI", "Jira", "RAID and change control", "Vendor management", "Requirements"],
    transferable: ["Multi vendor delivery", "Stakeholder alignment", "Framework design"],
  },
  {
    id: "disruptx",
    company: "Disrupt-X DMCC",
    place: "Dubai, UAE",
    title: "Product Manager, IoT Solutions and SaaS Platforms",
    earlier: "Product Engineer, Mar 2023 to Aug 2023, then Product Manager",
    dates: "Mar 2023 to Oct 2024",
    start: 2023,
    summary: "Promoted from Product Engineer to Product Manager within six months. Owned IoT SaaS platforms for smart city and enterprise clients across the UAE, Saudi Arabia and Oman.",
    bullets: [
      "Led product development for IoT SaaS platforms from concept to market deployment.",
      "Grew platform adoption by about 15% by improving onboarding and product market fit.",
      "Held a 95%+ UAT success rate across deployments through structured QA and cross functional testing.",
      "Represented the company at GITEX Dubai and supported presales and solution scoping.",
      "As Product Engineer: tested and integrated devices over LoRaWAN, NB-IoT, Sigfox, BLE, Wi-Fi and cellular, and wrote integration guides and onboarding procedures.",
    ],
    tools: ["LoRaWAN", "NB-IoT", "Sigfox", "BLE", "Cellular", "UAT"],
    transferable: ["Full product lifecycle", "Client discovery", "Quality assurance"],
  },
  {
    id: "samsung",
    company: "Samsung Electro-Mechanics (Philippines)",
    place: "Philippines",
    title: "Product Development Manager",
    earlier: "Product Development Engineer, Jul 2020 to Feb 2022, promoted to Product Development Manager in Feb 2022",
    dates: "Jul 2020 to Feb 2023",
    start: 2020,
    summary: "Electronic components for global manufacturing, from concept validation to mass production, working across R&D, process engineering, quality and production.",
    bullets: [
      "Led product development from concept validation through production ramp up.",
      "Coordinated R&D, process engineering, manufacturing, quality and production teams, including teams at Samsung headquarters in South Korea.",
      "Analysed production and quality data to find root causes and drive process improvement.",
      "Recognised with the Best Practitioner Award, Plating R&D (May 2022) and the Most Improved Process Award (2022).",
    ],
    tools: ["Root cause analysis", "Reliability testing", "Process improvement", "NPI"],
    transferable: ["Systems thinking", "Data informed problem solving", "Shipping when mistakes are costly"],
  },
];

export type Chapter = { id: string; year: string; title: string; kind: "Origin" | "Education" | "Work" | "Milestone" | "Now"; body: string; words?: string };
export const chapters: Chapter[] = [
  { id: "batangas", year: "Home", title: "Batangas, Philippines", kind: "Origin", body: "Batangas is home province. This is where the story starts." },
  { id: "scout", year: "2009 to 2015", title: "Eagle Scout", kind: "Milestone", body: "Six years with the Boy Scouts of the Philippines, finishing as a full pledged Eagle Scout. Leadership, community service and practical skills came from here." },
  { id: "uni", year: "2015 to 2020", title: "BS Electronics Engineering", kind: "Education", body: "University of Batangas. An internship as a system administrator at ResultsCX in 2019 was an early taste of real systems." },
  { id: "samsung", year: "2020 to 2023", title: "Samsung Electro-Mechanics", kind: "Work", body: "First career chapter: electronic components, from R&D concept to mass production. Promoted to Product Development Manager in February 2022.", words: "It taught me what it means to ship when a mistake costs a production line, not a sprint." },
  { id: "licence", year: "Apr 2022", title: "Licensed Electronics Engineer", kind: "Milestone", body: "Passed the Philippine Electronics Engineer Licensure Examination." },
  { id: "uae", year: "2023", title: "Moving to the UAE", kind: "Milestone", body: "Joined Disrupt-X in Dubai as a Product Engineer, then became Product Manager within six months.", words: "I kept applying frameworks I had learned elsewhere, and they did not land until I understood the context. Relationships here are the business layer." },
  { id: "aldar", year: "2024 to 2025", title: "Aldar Properties", kind: "Work", body: "Product Owner and Smart City Lead in Abu Dhabi, moving from owning one product to orchestrating an ecosystem of vendors and operations teams." },
  { id: "mba", year: "2024 to 2025", title: "MBA with Distinction", kind: "Education", body: "Philippine Christian University. Strategy, finance, operations and entrepreneurship, alongside full time work." },
  { id: "terminus", year: "2025 to 2026", title: "Terminus Group", kind: "Work", body: "Product Manager for AIoT and Digital Twin platforms, with presales across the GCC." },
  { id: "now", year: "Today", title: "Building what is next", kind: "Now", body: "Building my own products and learning how to make AI reliable inside real systems. See the Now page for the current picture." },
];

export type Capability = { id: string; name: string; short: string; links: string[]; evidence: string[] };
export const capabilities: Capability[] = [
  { id: "product", name: "Product Strategy", short: "Roadmaps, PRDs, prioritisation", links: ["systems", "platforms", "business"], evidence: ["Terminus: roadmap built from field feedback and constraints", "Disrupt-X: IoT SaaS from concept to deployment", "LIFE OS: scoped a broad brief into an eight module MVP"] },
  { id: "delivery", name: "Technical Delivery", short: "Multi vendor programmes, UAT", links: ["stakeholders", "analysis", "iot"], evidence: ["Aldar: Siemens, ID Cube and Parkonic through acceptance", "Disrupt-X: 95%+ UAT success rate", "Samsung: concept to mass production"] },
  { id: "systems", name: "Systems Thinking", short: "Engineering mindset", links: ["product", "iot", "research"], evidence: ["Electronics Engineering degree and licence", "Samsung: root cause analysis on production data", "Smart City Intelligence Hub: protocols and architectures mapped as a graph"] },
  { id: "analysis", name: "Business Analysis", short: "Requirements and use cases", links: ["delivery", "data", "platforms"], evidence: ["Aldar: use case and integration frameworks", "Terminus: system blueprints and integration flow specs", "Smart City Solution Blueprint"] },
  { id: "platforms", name: "Digital Platforms", short: "Enterprise and SaaS", links: ["product", "analysis", "iot"], evidence: ["Terminus: AIoT and Digital Twin platforms", "Disrupt-X: IoT SaaS platforms", "Technical governance across cybersecurity and data integrity"] },
  { id: "research", name: "Research and Prototyping", short: "Learn, build, test", links: ["systems", "business", "data"], evidence: ["Smart City Intelligence Hub", "Wakeful Morning prototype in Expo and React Native", "CareerOS and LIFE OS"] },
  { id: "stakeholders", name: "Stakeholder Management", short: "Across cultures and functions", links: ["delivery", "business"], evidence: ["Government, developers, vendors and operations at Aldar", "Clients in the UAE, Saudi Arabia and Oman at Disrupt-X", "Teams at Samsung headquarters in South Korea"] },
  { id: "data", name: "Data Informed Decisions", short: "Measure, then decide", links: ["analysis", "research"], evidence: ["Aldar: post deployment adoption tracking", "Power BI dashboards for executives", "Samsung: production and quality data analysis"] },
  { id: "iot", name: "IoT and AIoT", short: "Connected technologies", links: ["systems", "delivery", "platforms"], evidence: ["LoRaWAN, NB-IoT, Sigfox, BLE, Wi-Fi, cellular integration", "Digital twin and smart city programmes", "Smart City Intelligence Hub: 22+ protocols"] },
  { id: "business", name: "Business and Entrepreneurial Thinking", short: "MBA, products, presales", links: ["product", "stakeholders", "research"], evidence: ["MBA with Distinction", "Presales at Disrupt-X and Terminus", "Five products built on my own time"] },
];

export type Project = {
  slug: string;
  name: string;
  status?: Status;
  type: "Personal" | "Professional";
  period: string;
  blurb: string;
  tech: string[];
  problem?: string;
  users?: string;
  role?: string;
  approach?: string[];
  decisions?: string[];
  results?: string[];
  roadmap?: string[];
  links?: { label: string; href: string }[];
  shot?: { src: string; alt: string; caption: string };
};

export const projects: Project[] = [
  {
    slug: "smart-city-intelligence-hub",
    name: "Smart City Intelligence Hub",
    status: "In Development",
    type: "Personal",
    period: "May 2026 to present",
    blurb: "A free, interactive platform that maps the smart city and IoT ecosystem as one connected knowledge graph.",
    tech: ["Next.js", "React", "TypeScript", "Tailwind CSS", "shadcn/ui", "React Flow"],
    problem: "Information in smart cities and IoT is fragmented. MQTT is explained in one place, digital twins in another and smart buildings somewhere else, so it is hard to see how it all connects.",
    users: "People entering or advancing in smart cities, IoT and product management.",
    role: "Product owner, designer and builder.",
    approach: [
      "22+ IoT protocols explained from beginner to technical depth.",
      "Smart city subsystems and how they interact.",
      "18+ solution architectures with KPIs and implementation notes.",
      "Global case studies including Singapore, Dubai, Barcelona, NEOM, Amsterdam, Seoul and Masdar City.",
      "An interactive knowledge graph so users explore connections, not isolated definitions.",
    ],
    results: ["Started as a personal learning tool. I now use it for research, client conversations and solution design."],
    roadmap: ["Gather feedback from practitioners", "Decide what to add next, based on what users ask for"],
    links: [
      { label: "Live platform", href: "https://smart-city-intelligence-hub.vercel.app" },
    ],
  },
  {
    slug: "life-os",
    name: "LIFE OS (Project 2035)",
    status: "Prototype",
    type: "Personal",
    period: "2026 to present",
    blurb: "A local first planning app that connects long term goals to what to do today, and adapts when you fall behind.",
    tech: ["Next.js", "TypeScript", "SQLite", "Automated tests"],
    problem: "Goals fall apart the first time you miss a week. Goals lived in notes, numbers lived in my head, and daily tasks had no link to either.",
    users: "Someone in a transition, rebuilding routines, money or a career, who wants structure without guilt and does not want to hand personal data to a cloud service.",
    role: "Product owner, designer and builder.",
    approach: [
      "Every long term goal is cut into milestones and small daily actions.",
      "Plans adapt to capacity with Minimum, Standard and Deep Work modes.",
      "A daily plan that adapts to capacity, regular check ins on energy, mood, wins and blockers, a six stage roadmap, money tracking and a growth area for habits and learning.",
    ],
    decisions: [
      "Staged, not parallel. Six ordered life stages, one in focus at a time, because nine areas competing for attention is how people quit.",
      "A Minimum Day. Every routine has a smaller version that still counts, because the product is judged on whether it survives a bad week.",
      "Plans are seeded, facts are not. No balance, application or achievement is pre filled, so every number on screen was entered by the user.",
      "Scope is a feature. A broad brief became eight modules. The rest is sequenced, not dropped.",
    ],
    results: ["Works as a personal tool, with a public demo on fictional data."],
    roadmap: ["Keep using it daily and fix what breaks", "Decide whether it is useful to anyone but me"],
    links: [
      { label: "Live demo (fictional data)", href: "https://lifeos35-demo.vercel.app" },
      { label: "Code on GitHub", href: "https://github.com/romemcg/life-os" },
      { label: "Walkthrough (LinkedIn)", href: "https://lnkd.in/dT7yqCMx" },
    ],
  },
  {
    slug: "careeros",
    name: "CareerOS",
    status: "In Development",
    type: "Personal",
    period: "2026 to present",
    blurb: "A local desktop app for job search that builds tailored CVs from verified facts only, so it cannot invent claims.",
    tech: ["Tauri 2", "React", "TypeScript", "SQLite", "Rust"],
    problem: "Tailoring a CV for every role by hand is slow, and AI tools are happy to invent metrics. A CV that cannot survive a background check is worse than none.",
    users: "Me first. Anyone who needs to tailor applications without fabricating.",
    role: "Product owner, designer and builder.",
    approach: [
      "Import a master CV, verify each fact, then match facts against a job description.",
      "Generate a tailored CV from verified facts in an exact template.",
      "Everything runs locally on the Mac. The API key lives in the system keychain, never in the interface.",
    ],
    decisions: [
      "The database itself enforces that only verified facts can appear on a CV.",
      "The AI only selects and orders pre verified bullets. It never writes new claims.",
      "Local first, because a job search holds private data.",
    ],
    results: ["In active development."],
    roadmap: ["Finish the paste a job description, review, approve, generate flow", "Use it on real applications and measure what helps"],
  },
  {
    slug: "gulf-hiring-radar",
    name: "Gulf Hiring Radar",
    status: "Prototype",
    type: "Personal",
    period: "Oct 2026",
    blurb: "A tracker of live openings and career portals across the UAE and Oman, refreshed each weekday by a scheduled agent.",
    tech: ["Shared database", "Scheduled agent", "Job search APIs"],
    problem: "Checking dozens of career pages by hand is slow, and good postings go stale within days.",
    users: "Me, during an active job search.",
    role: "Product definition, filters and rules, and the agent's instructions.",
    approach: [
      "Live openings with a fit rating and a status I can change.",
      "A daily agent that finds new postings and records them, but never applies or messages anyone for me.",
      "My own hard blockers applied as filters.",
    ],
    results: ["A working tracker that refreshes every weekday."],
  },
  {
    slug: "aldar-connected-communities",
    name: "Aldar Connected Communities",
    type: "Professional",
    period: "Oct 2024 to Oct 2025",
    blurb: "Smart community technology across Saadiyat, Mamsha and The Grove, from master plan vision to daily operations.",
    tech: ["IoT", "Building systems", "BIM", "Power BI"],
    problem: "Move smart community technology from vision to operations across several developments, with multiple vendors and thousands of homes.",
    role: "Product Owner and Smart City Lead for the digital platforms.",
    approach: [
      "Capabilities spanned smart home, mobility, parking, building intelligence, the Harbour resident app, predictive maintenance and the Command and Control Centre.",
      "Coordinated Siemens, ID Cube and Parkonic with internal ICT, sustainability and operations teams.",
      "Set MVP site selection criteria and post deployment adoption tracking.",
    ],
    results: ["About 30% better monitoring efficiency, about 40% faster failure response and about 25% lower energy costs. Digital platforms portfolio valued at AED 30M+."],
  },
  {
    slug: "terminus-presales-programmes",
    name: "Terminus Government and Enterprise Programmes",
    type: "Professional",
    period: "Oct 2025 to Aug 2026",
    blurb: "Presales and solution definition for municipal, destination and smart home opportunities across the GCC.",
    tech: ["AIoT", "Digital twin", "PRDs", "Integration specs"],
    problem: "Turn enterprise and government needs into solutions that engineering can validate and deliver.",
    role: "Product and Presales Manager.",
    approach: [
      "Opportunities included a Dubai Municipality wastewater management initiative, Miral Smart Destination and Al Wasl Smart Home.",
      "Also supported an Aldar smart home mock up villa and Terminus' AI City Operating System (TacOS) and IoC digital twin solutions.",
      "Coordinated feasibility with engineering and solution architecture, and wrote the requirements and integration documentation.",
    ],
    results: ["Contributed to proposals, solution definition and requirements across these opportunities."],
  },
  {
    slug: "disrupt-x-iot-platforms",
    name: "Disrupt-X IoT SaaS Platforms",
    type: "Professional",
    period: "Mar 2023 to Oct 2024",
    blurb: "IoT SaaS for smart city and enterprise clients in the UAE, Saudi Arabia and Oman.",
    tech: ["LoRaWAN", "NB-IoT", "Sigfox", "BLE", "Cellular", "UAT"],
    problem: "Enterprise and government clients were buying IoT hardware but struggling to turn it into operational value. Adoption, not connectivity, was the bottleneck.",
    role: "Product Engineer, then Product Manager within six months.",
    approach: ["Owned the lifecycle from concept to market deployment.", "Improved onboarding and product market fit.", "Ran structured QA and cross functional testing."],
    results: ["About 15% platform adoption growth and a 95%+ UAT success rate across deployments."],
  },
  {
    slug: "disrupt-x-marketplace",
    name: "Disrupt-X Marketplace",
    type: "Professional",
    period: "Disrupt-X",
    blurb: "An enterprise marketplace and content management product experience at Disrupt-X.",
    tech: ["Marketplace", "Content management"],
    role: "Product Manager.",
    results: ["Employer work, kept high level."],
  },
  {
    slug: "wakeful-morning",
    name: "Wakeful Morning",
    status: "Prototype",
    type: "Personal",
    period: "Jul 2026 to present",
    shot: { src: "/img/projects/wakeful-morning-onboarding.webp", alt: "Wakeful Morning onboarding screen listing the four wake-up steps", caption: "The onboarding screen of the Wakeful Morning prototype." },
    blurb: "A mobile alarm and morning focus app for heavy sleepers, built around wake challenges instead of a snooze button.",
    tech: ["Expo", "React Native", "Device sensors", "Local storage"],
    problem: "For heavy sleepers, a normal alarm is easy to dismiss and go back to sleep.",
    users: "Heavy sleepers who want to wake up and stay awake.",
    role: "Product definition, behavioural design, safety requirements and the prototype build.",
    approach: [
      "Configurable alarms with motion based wake challenges.",
      "Camera assisted location verification and post wake distraction controls.",
      "Structured for a future native Android and iOS build, where system level alarms and stronger app restrictions are possible.",
    ],
    results: ["A working cross platform prototype."],
    roadmap: ["Native Android and iOS integration for system level alarms"],
  },
];

export type CaseStudy = {
  slug: string;
  title: string;
  category: string;
  context: string;
  blurb: string;
  problem: string;
  approach: string[];
  decisions: string[];
  outcome: string[];
  learned: string;
  flow: string[];
};

export const caseStudies: CaseStudy[] = [
  {
    slug: "smart-city-solution-blueprint",
    title: "From vendor pitches to a repeatable decision",
    category: "Product Management and Digital Transformation",
    context: "Aldar Properties, Abu Dhabi. Proprietary details are left out.",
    blurb: "How a reusable scoring framework replaced ad hoc smart city vendor selection across three developments.",
    problem: "Smart city solutions were being evaluated one at a time, often from vendor pitches. Each development repeated the planning work, and there was no shared way to compare options or to say why one was chosen.",
    approach: [
      "Defined a reusable blueprint covering digital use cases, a vendor evaluation checklist, scoring criteria and an impact assessment.",
      "Used seven evaluation criteria so different solutions could be compared on the same basis.",
      "Applied it across Saadiyat, Mamsha and The Grove, and paired it with MVP site selection criteria and post deployment adoption tracking.",
    ],
    decisions: [
      "Score first, shortlist second. Vendors are compared on criteria agreed before the pitch, not after.",
      "Reusable over perfect. One framework applied three times beat three bespoke assessments.",
      "Track adoption after launch. Delivery is not the finish line, adoption is.",
    ],
    outcome: [
      "The framework was applied across three developments.",
      "It structured solution evaluation and reduced repeated planning work.",
    ],
    flow: ["Vendor pitches", "Common criteria", "Scoring matrix", "Impact assessment", "Repeatable decision"],
    learned: "A framework is a product. It needs users, a clear job and a reason to be used again.",
  },
  {
    slug: "smart-education-smart-cities",
    title: "Smart education in the smart city",
    category: "Research and Strategy",
    context: "Independent research report, 2025.",
    blurb: "A research report on where technology has worked in education, from classrooms and campus operations to safety, energy and lifelong learning.",
    problem: "Smart city programmes often treat education as a service to be digitised. The question I set out to answer was whether education is better understood as a driver of the city's intelligence, and what has worked in practice.",
    approach: [
      "Reviewed published case studies and programmes across six areas: learning, campus operations, safety, sustainability, workforce development and lifelong learning.",
      "Mapped each use case to the technologies involved and the benefit it produced.",
      "Linked the findings to the six smart city pillars: people, living, mobility, economy, environment and governance.",
    ],
    decisions: [
      "Treat education as a driver of the city, not only a user of its technology.",
      "Judge a use case by the outcome it produced, for example a sensor based parking system at the University of Delaware or solar plus batteries offsetting up to 60% of energy costs at Stockton Unified School District.",
      "Name the conditions for success: stakeholder collaboration, data privacy and digital equity, and phased rollouts.",
    ],
    outcome: [
      "A structured report with comparison tables of use cases, technologies and illustrative implementations.",
      "A set of success factors for planning smart education inside a city programme.",
    ],
    flow: ["Education in the smart city", "Use cases by area", "Technologies and benefits", "Case studies", "Success factors"],
    learned: "Technology adoption is the easy part. Privacy, equity and community buy in decide whether it lasts.",
  },
  {
    slug: "live-aldar-app-review",
    title: "Live Aldar app: a product review",
    category: "Product Analysis",
    context: "Hands on review of the public Live Aldar mobile app, Android and iOS.",
    blurb: "A manual, scenario based review of the Live Aldar app, looking at usability, performance and design in the flows anyone can reach without an account.",
    problem: "Most reviews of a resident app start from a logged in user. I wanted to see what a person experiences before signing up, and where the public flows lose them.",
    approach: [
      "Tested on mid range and flagship phones running current Android and iOS, over Wi-Fi and mobile data, against production servers.",
      "Used manual exploratory testing and scenario checks: the Education section, Manage Properties, Property Search, Explore a Community and Darna Rewards.",
      "Stayed inside publicly accessible features. No sign up flow was pursued.",
    ],
    decisions: [
      "Test real devices and real networks, not only the ideal case.",
      "Review the public journey separately from the account journey.",
    ],
    outcome: [
      "A written review of usability, performance and design gaps in the public flows.",
    ],
    flow: ["Scope public flows", "Test on devices", "Switch networks", "Log gaps", "Review summary"],
    learned: "The first minutes without an account are a product in their own right.",
  },
  {
    slug: "life-as-a-product",
    title: "Treating my own life as a product",
    category: "Personal Experiments and Product Discovery",
    context: "Personal project, 2026.",
    blurb: "Why a ten year plan did not tell me what to do on a Tuesday morning, and what I built instead.",
    problem: "Vision boards and long roadmaps feel productive but do not tell you what to do at 9 a.m. on a Tuesday. My goals lived in notes, my numbers lived in my head, and my daily tasks had no link to either.",
    approach: [
      "Wrote the problem, user and approach down before building, as I would for any product.",
      "Scoped a broad brief into an eight module MVP and sequenced the rest.",
      "Built it local first so personal data stays on my device.",
    ],
    decisions: [
      "One life stage in focus at a time, with later stages locked until the current one is stable.",
      "A smaller Minimum Day that still counts.",
      "Actuals and projections are never mixed, and no number is pre filled.",
    ],
    outcome: ["A working app with a demo mode on fictional data."],
    flow: ["Goals in notes", "Six life stages", "Milestones", "Daily actions", "Adapts to a bad week"],
    learned: "You cannot solve what you cannot see. Saying not yet matters as much as saying yes.",
  },
  {
    slug: "ai-that-cannot-invent",
    title: "Designing AI that cannot invent facts",
    category: "Product Management and Technology Research",
    context: "CareerOS, personal project, 2026.",
    blurb: "A job search tool where the AI can only choose from facts I have already verified.",
    problem: "AI writing tools will invent metrics if asked, and screeners probe for consistency. In a job search, one fabricated number can end an application.",
    approach: [
      "Split the system in two: a verified fact store, and an AI step that only selects and orders from it.",
      "Made the rule structural, not a prompt instruction, by enforcing it in the database.",
      "Kept everything on the local machine, with the API key in the keychain.",
    ],
    decisions: [
      "Constrain the system instead of trusting the model.",
      "Verification is a human step, done once, then reused.",
      "Local first, because the data is private.",
    ],
    outcome: ["The fact importer and verification screen work on a real master CV."],
    flow: ["Master CV", "Verified fact store", "AI selects and orders", "Tailored CV"],
    learned: "Reliability in AI products usually comes from the structure around the model.",
  },
];


export const now = {
  focus: "Building products, learning how to make AI reliable inside real systems, and working out what comes next.",
  building: ["CareerOS, the local first job search tool", "LIFE OS, a planning app that survives a bad week", "Smart City Intelligence Hub, adding what practitioners ask for", "Wakeful Morning, moving toward native alarms"],
  learning: ["Agentic AI and multi agent systems", "Model Context Protocol", "AI evaluation frameworks", "Production AI architectures"],
  recent: ["EPFL: Smart Cities, Management of Smart Urban Infrastructures (Sep 2026)", "PMI: Introduction to Large Language Models (Jul 2026)"],
};

export const certs = [
  "Licensed Electronics Engineer (Philippines), April 2022",
  "Registered Electronics Technician (Philippines), 2022",
  "Registered Technical Engineer (Philippines)",
  "Certified Scrum Product Owner (CSPO), Scrum Alliance",
  "EPFL: Smart Cities, Management of Smart Urban Infrastructures, Sep 2026",
  "PMI: Introduction to Large Language Models, Jul 2026",
];

export const education = [
  { school: "Philippine Christian University", what: "Master of Business Administration, with Distinction", dates: "2024 to 2025" },
  { school: "University of Batangas", what: "BS Electronics Engineering", dates: "2015 to 2020" },
];

export const recruiterSummary =
  "Technical Product Manager and Product Owner with nearly six years across electronics manufacturing, IoT SaaS, smart city programmes and AIoT platforms in the Philippines and the UAE. Licensed Electronics Engineer, MBA with Distinction, CSPO. Strongest at platform product ownership, technical documentation, multi vendor delivery and turning stakeholder needs into shippable scope.";

export type Rec = { name: string; role: string; org: string; quote: string };
export const recommendations: Rec[] = [
  {
    "name": "Tony Pagliocco",
    "role": "Associate Director, Product Management",
    "org": "Aldar Properties PJSC",
    "quote": "Mark’s contributions to our Smart City IoT team were exceptional from day one. He brought both practical and forward-thinking expertise, quickly becoming indispensable to our agile delivery teams. His attention to detail, commitment to quality, and constant drive to learn set him apart. What impressed me most was his ability to combine technical depth with human empathy, earning respect, elevating those around him, and driving true innovation."
  },
  {
    "name": "Salah Berkane",
    "role": "IoT Director",
    "org": "Tadoom Oman",
    "quote": "Mark has a deep understanding of IoT technologies and consistently demonstrates a strong problem-solving ability. He always approaches challenges with a positive attitude and is always willing to go the extra mile to ensure our satisfaction. His collaborative mindset and willingness to share knowledge helped us a lot as well."
  },
  {
    "name": "Nazha Nayim",
    "role": "Lead Product Manager",
    "org": "Disrupt-X",
    "quote": "I’ve had the pleasure of working closely with Mark, and his highly organized and structured approach has been invaluable. He’s a true team player, always willing to help, and consistently takes the initiative in identifying and addressing gaps. What sets Mark apart is his ability to quickly learn and adapt to new challenges, making his contributions on the product management side particularly commendable."
  },
  {
    "name": "Muhammad Uzair Akhtar",
    "role": "Product Specialist",
    "org": "DynaSys Network Pakistan",
    "quote": "Mark is a great professional with extensive knowledge of IoT. I had the pleasure of being trained by him on the importance of having a marketplace and a CMS for the success of any IoT Platform."
  },
  {
    "name": "Ronnie Francisco",
    "role": "Technical Supervisor",
    "org": "ABM Olayan Saudi Arabia",
    "quote": "He has consistently impressed me with his expertise as an IoT Product Manager. His deep understanding of IoT technologies, combined with his ability to manage complex projects, sets him apart in the industry. Mark has an exceptional talent for collaborating across teams, solving challenges, and driving innovation. I’ve seen firsthand how his leadership and strategic thinking have contributed to the success of key projects."
  },
  {
    "name": "Ruba Ibrahim",
    "role": "Lead Product Manager",
    "org": "Disrupt-X",
    "quote": "Mark is a proactive and detail-oriented Product Manager with a remarkable ability to visualize product requirements in a creative and comprehensive manner. They excel at breaking down complex needs into detailed story maps, ensuring clear communication and smooth delivery to the development team."
  },
  {
    "name": "Hanaa Othman",
    "role": "Marketing Manager",
    "org": "Disrupt-X",
    "quote": "It’s been great working alongside Mark. He’s incredibly organized, attentive to detail, and always open to feedback. His proactive approach and positive attitude will be missed. Even from the marketing side, it’s clear he’s dedicated and collaborative. Wishing him a great success in his next role!"
  },
  {
    "name": "Kuhan Jaganathan",
    "role": "Product Manager",
    "org": "Disrupt-X",
    "quote": "Mark has been an invaluable member that has constantly prioritises self improvement. His efforts in product development has been of great value as he has the ability to concisely deliver large scale ideas. Never walking away from a task, he has supported numerous developments. With excellent documentation skills, he has elevated collaboration across the teams and clients. Great experience working with him."
  },
  {
    "name": "George Ding",
    "role": "VP of Delivery, Partnership, Operations",
    "org": "Terminus Group",
    "quote": "Mark is a hard working and reliable member, while working as product & presales manager in my team. He is very responsible for any work assigned to him, which usually requires multi-tasking and quick learning capabilities. He demonstrated a very proactive attitude and willingness to take extra effort to deliver quality results. He attended to details to produce thoroughly analyzed and well structured documentations for product requirement specs. He was able to contribute to major opportunities with real estate and municipality customers in UAE, for solutions in the domains of AIoT, smart-city, digital-twin and smart home/building devices."
  },
  {
    "name": "Numan Al Omary",
    "role": "Senior Commercial, Sales and Transformation Leader",
    "org": "",
    "quote": "Mark has been great to work with. He's highly collaborative, quickly understands customer requirements, and does an excellent job turning them into practical solutions. He has a keen attention to detail, builds clear and professional customer and product presentations, and explains complex technical concepts in a simple, engaging way. Always willing to support the team, Mark is a real asset to any organization."
  }
];

export const transformation = {
  from: "110 kg",
  to: "67 kg",
  text: "A 43 kg transformation. It strengthened my discipline, focus and resilience, and I bring the same habits to every product challenge.",
};

export const disruptxProjects = [
  { name: "Abu Dhabi Equestrian Club", scope: "Environmental Monitoring", img: "equestrian" },
  { name: "Emirates Golf Club", scope: "Environmental Monitoring and Asset Tracking", img: "golf" },
  { name: "Masdar City", scope: "Smart City Solutions, Environmental Monitoring and Occupancy Tracking", img: "masdar" },
  { name: "Al Ghurair Centre", scope: "Environmental Monitoring and Asset Tracking", img: "ghurair" },
  { name: "Al Wasl Residence", scope: "Smart City Solutions and Environmental Monitoring", img: "alwasl" },
];

export const aldarProjects = [
  { name: "Saadiyat District: Smart Parking and Mobility Platform", body: "Assessed and coordinated a unified smart parking integration across Mamsha and Saadiyat communities.", img: "saadiyat" },
  { name: "Project Nexus: Command and Control Centre", body: "Reviewed technical site surveys for 80+ assets across BMS, security, access control, CCTV and fire alarm systems, and produced consultant ready review summaries.", img: "nexus" },
  { name: "Smart Communities and Digital Experience Strategy", body: "Refined Aldar's smart community and digital experience blueprint using reusable IoT modules and prioritised, vendor agnostic use cases.", img: "smartcomm" },
  { name: "Smart City Use Case Blueprint (Confluence)", body: "Built vendor agnostic Confluence templates for wayfinding, access, air quality, irrigation, safety, waste and more, linking personas, use cases, value and ROI.", img: "blueprint" },
];
