import { Logo } from "./Logo";
import { TechIcon } from "./Icons";
import { Reveal } from "./Reveal";

const places = [["samsung", "Samsung Electro-Mechanics"], ["disruptx", "Disrupt-X"], ["aldar", "Aldar Properties"], ["terminus", "Terminus Group"]];
const tech = ["Next.js", "React", "TypeScript", "Tailwind CSS", "Rust", "SQLite", "Expo", "Claude"];

export function LogoStrip() {
  return (
    <Reveal className="wrap pb-12">
      <p className="text-center text-xs font-semibold uppercase tracking-[0.18em] text-soft">Where I have worked</p>
      <div className="mt-6 grid grid-cols-2 justify-items-center gap-x-6 gap-y-7 md:grid-cols-4">
        {places.map(([id, n]) => (
          <div key={id} className="flex flex-col items-center gap-2.5">
            <Logo id={id} name={n} size={72} />
            <span className="text-xs font-medium text-soft">{n.replace(" Electro-Mechanics", "").replace(" Properties", "").replace(" Group", "")}</span>
          </div>
        ))}
      </div>
    </Reveal>
  );
}

export function TechStrip() {
  return (
    <Reveal className="wrap pb-14 pt-2">
      <p className="text-center text-xs font-semibold uppercase tracking-[0.18em] text-soft">Tools I build with</p>
      <div className="mt-5 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-soft">
        {tech.map((t) => <span key={t} title={t} className="flex items-center gap-2 text-sm"><TechIcon name={t} className="h-5 w-5" />{t}</span>)}
      </div>
    </Reveal>
  );
}
